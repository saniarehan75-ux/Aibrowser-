package com.privatebrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    static final String ASSET_HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + ASSET_HOST + "/assets/home.html";
    static final String AI_HUB = "https://" + ASSET_HOST + "/assets/ai-hub.html";
    static final int REQ_VOICE = 77;
    static final int REQ_FILE = 78;
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    static final String[] BLOCK = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
            "googletagmanager.com", "googletagservices.com", "adservice.google.com", "facebook.net",
            "scorecardresearch.com", "taboola.com", "outbrain.com", "adnxs.com", "criteo.com", "criteo.net",
            "hotjar.com", "quantserve.com", "amazon-adsystem.com", "adsrvr.org", "pubmatic.com",
            "rubiconproject.com", "moatads.com", "chartbeat.com", "mixpanel.com", "ads-twitter.com",
            "analytics.twitter.com", "mc.yandex.ru", "clarity.ms", "adform.net", "openx.net",
            "casalemedia.com", "smartadserver.com", "popads.net", "propellerads.com", "adcolony.com",
            "applovin.com", "unity3d.com", "inmobi.com", "mopub.com"
    };

    static class Tab {
        WebView web;
        String title = "";
    }

    SharedPreferences prefs;
    WebViewAssetLoader assetLoader;
    final List<Tab> tabs = new ArrayList<>();
    int cur = -1;
    FrameLayout content;
    EditText urlBox;
    ProgressBar progress;
    TextView tabBtn;
    boolean blockOn, desktop, saver;
    String engine;
    final AtomicInteger blocked = new AtomicInteger(0);
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> filePathCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("pb", MODE_PRIVATE);
        blockOn = prefs.getBoolean("block", true);
        desktop = prefs.getBoolean("desktop", false);
        saver = prefs.getBoolean("saver", false);
        engine = prefs.getString("engine", "google");
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(ASSET_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        CookieManager.getInstance().removeAllCookies(null);
        buildUi();
        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri d = intent.getData();
        if (d != null) newTab(d.toString());
    }

    /* ---------------- UI ---------------- */

    int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    GradientDrawable rounded(String color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(color));
        g.setCornerRadius(radius);
        return g;
    }

    TextView navBtn(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(26);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.parseColor("#C9D1DC"));
        t.setOnClickListener(l);
        return t;
    }

    void buildUi() {
        int bg = Color.parseColor("#0E1116");
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setFitsSystemWindows(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10), dp(8), dp(10), dp(8));

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setHint("Search karein ya address likhein");
        urlBox.setHintTextColor(Color.parseColor("#9AA4B2"));
        urlBox.setTextColor(Color.parseColor("#E8ECF2"));
        urlBox.setTextSize(15);
        urlBox.setBackground(rounded("#171B22", dp(22)));
        urlBox.setPadding(dp(16), 0, dp(16), 0);
        urlBox.setSelectAllOnFocus(true);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBox.getText().toString());
                urlBox.clearFocus();
                hideKeyboard();
                return true;
            }
            return false;
        });
        top.addView(urlBox, new LinearLayout.LayoutParams(0, dp(44), 1f));

        TextView mic = new TextView(this);
        mic.setText("🎤");
        mic.setTextSize(20);
        mic.setGravity(Gravity.CENTER);
        mic.setBackground(rounded("#3DDC97", dp(22)));
        mic.setOnClickListener(v -> voice());
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(44), dp(44));
        mlp.leftMargin = dp(8);
        top.addView(mic, mlp);
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        progress.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#3DDC97")));
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#1E242D"));
        root.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(bg);
        tabBtn = navBtn("1", v -> showTabs());
        tabBtn.setTextSize(15);
        tabBtn.setTypeface(null, android.graphics.Typeface.BOLD);
        nav.addView(navBtn("‹", v -> back()), navLp());
        nav.addView(navBtn("›", v -> forward()), navLp());
        nav.addView(navBtn("⌂", v -> home()), navLp());
        nav.addView(tabBtn, navLp());
        nav.addView(navBtn("⋮", v -> showMenu()), navLp());
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        setContentView(root);
    }

    LinearLayout.LayoutParams navLp() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    /* ---------------- Tabs ---------------- */

    WebView curWeb() {
        return tabs.get(cur).web;
    }

    boolean isCur(WebView v) {
        return cur >= 0 && cur < tabs.size() && tabs.get(cur).web == v;
    }

    void newTab(String url) {
        Tab t = new Tab();
        t.web = makeWebView();
        tabs.add(t);
        selectTab(tabs.size() - 1);
        loadUrlIn(t.web, url);
    }

    void selectTab(int i) {
        if (cur >= 0 && cur < tabs.size()) content.removeView(tabs.get(cur).web);
        cur = i;
        content.addView(tabs.get(i).web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        updateUi();
    }

    void closeTab(int i) {
        Tab t = tabs.get(i);
        boolean wasCur = (i == cur);
        if (wasCur) content.removeView(t.web);
        t.web.destroy();
        tabs.remove(i);
        if (tabs.isEmpty()) {
            cur = -1;
            newTab(HOME);
            return;
        }
        if (wasCur) {
            cur = -1;
            selectTab(Math.min(i, tabs.size() - 1));
        } else {
            if (i < cur) cur--;
            updateUi();
        }
    }

    void closeAll() {
        wipe(false);
        if (cur >= 0 && cur < tabs.size()) content.removeView(tabs.get(cur).web);
        for (Tab t : tabs) t.web.destroy();
        tabs.clear();
        cur = -1;
        newTab(HOME);
    }

    void updateUi() {
        tabBtn.setText(String.valueOf(tabs.size()));
        progress.setVisibility(View.GONE);
        showUrl(curWeb().getUrl());
    }

    void showUrl(String url) {
        if (urlBox.hasFocus()) return;
        if (url == null || url.contains(ASSET_HOST)) urlBox.setText("");
        else urlBox.setText(url);
    }

    void showTabs() {
        List<String> items = new ArrayList<>();
        for (int i = 0; i < tabs.size(); i++) {
            String name = tabs.get(i).title;
            if (name == null || name.isEmpty()) name = "Naya tab";
            items.add((i == cur ? "● " : "") + name);
        }
        items.add("+ Naya tab");
        items.add("Maujooda tab band karein");
        items.add("Sab tabs band karein");
        final int n = tabs.size();
        new AlertDialog.Builder(this)
                .setTitle("Tabs (" + n + ")")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    if (which < n) selectTab(which);
                    else if (which == n) newTab(HOME);
                    else if (which == n + 1) closeTab(cur);
                    else closeAll();
                })
                .show();
    }

    /* ---------------- WebView ---------------- */

    WebView makeWebView() {
        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.parseColor("#0E1116"));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        applyMode(w);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, false);
        w.setWebViewClient(new Client());
        w.setWebChromeClient(new Chrome());
        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime);
                req.addRequestHeader("User-Agent", ua);
                String c = CookieManager.getInstance().getCookie(url);
                if (c != null) req.addRequestHeader("Cookie", c);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                toast("Download shuru ho gaya");
            } catch (Exception e) {
                toast("Ye download nahi ho saka");
            }
        });
        return w;
    }

    void applyMode(WebView w) {
        WebSettings s = w.getSettings();
        s.setUserAgentString(desktop ? DESKTOP_UA : null);
        s.setBlockNetworkImage(saver);
    }

    Map<String, String> dntHeaders() {
        Map<String, String> h = new HashMap<>();
        h.put("DNT", "1");
        h.put("Sec-GPC", "1");
        return h;
    }

    void loadUrlIn(WebView w, String url) {
        w.loadUrl(url, dntHeaders());
    }

    boolean isBlocked(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        for (String b : BLOCK) {
            if (h.equals(b) || h.endsWith("." + b)) return true;
        }
        return false;
    }

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (ASSET_HOST.equals(u.getHost())) {
                return assetLoader.shouldInterceptRequest(u);
            }
            if (blockOn && !r.isForMainFrame() && isBlocked(u.getHost())) {
                blocked.incrementAndGet();
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            if (ASSET_HOST.equals(u.getHost()) && "/search".equals(u.getPath())) {
                String q = u.getQueryParameter("q");
                go(q == null ? "" : q);
                return true;
            }
            if (scheme.equals("http") || scheme.equals("https")) {
                if (r.isForMainFrame() && !r.isRedirect() && "GET".equalsIgnoreCase(r.getMethod())) {
                    v.loadUrl(u.toString(), dntHeaders());
                    return true;
                }
                return false;
            }
            if (scheme.equals("mailto") || scheme.equals("tel") || scheme.equals("sms")) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // ignore
                }
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            if (isCur(v)) {
                progress.setVisibility(View.VISIBLE);
                showUrl(url);
            }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (isCur(v)) {
                progress.setVisibility(View.GONE);
                showUrl(url);
            }
        }
    }

    class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            if (isCur(v)) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        }

        @Override
        public void onReceivedTitle(WebView v, String t) {
            for (Tab x : tabs) {
                if (x.web == v) x.title = t;
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            ((FrameLayout) getWindow().getDecorView()).addView(view,
                    new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (filePathCb != null) {
                filePathCb.onReceiveValue(null);
            }
            filePathCb = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                filePathCb = null;
                toast("File chooser nahi khul saka");
                return false;
            }
            return true;
        }
    }

    void hideCustom() {
        if (customView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    /* ---------------- Navigation ---------------- */

    String searchUrl(String q) {
        String e = Uri.encode(q);
        switch (engine) {
            case "startpage":
                return "https://www.startpage.com/do/search?q=" + e;
            case "ddg":
                return "https://duckduckgo.com/?q=" + e;
            default:
                return "https://www.google.com/search?q=" + e;
        }
    }

    String engineName() {
        switch (engine) {
            case "startpage":
                return "Startpage";
            case "ddg":
                return "DuckDuckGo";
            default:
                return "Google";
        }
    }

    void go(String in) {
        in = in.trim();
        if (in.isEmpty()) return;
        String url;
        if (in.startsWith("http://") || in.startsWith("https://")) url = in;
        else if (in.indexOf(' ') < 0 && in.contains(".") && !in.endsWith(".")) url = "https://" + in;
        else url = searchUrl(in);
        loadUrlIn(curWeb(), url);
    }

    void back() {
        if (curWeb().canGoBack()) curWeb().goBack();
    }

    void forward() {
        if (curWeb().canGoForward()) curWeb().goForward();
    }

    void home() {
        loadUrlIn(curWeb(), HOME);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        if (curWeb().canGoBack()) {
            curWeb().goBack();
            return;
        }
        if (tabs.size() > 1) {
            closeTab(cur);
            return;
        }
        super.onBackPressed();
    }

    /* ---------------- Voice ---------------- */

    void voice() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolein...");
        try {
            startActivityForResult(i, REQ_VOICE);
        } catch (ActivityNotFoundException e) {
            toast("Is phone mein voice search maujood nahi");
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == REQ_FILE) {
            if (filePathCb != null) {
                filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
                filePathCb = null;
            }
            return;
        }
        if (rq == REQ_VOICE && rs == RESULT_OK && d != null) {
            ArrayList<String> r = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                urlBox.setText(r.get(0));
                go(r.get(0));
            }
        }
    }

    /* ---------------- Menu ---------------- */

    void showMenu() {
        String[] items = {
                "Naya tab",
                "Sab AI Ek Sath (AI Hub)",
                "Desktop site: " + (desktop ? "ON" : "OFF"),
                "Data saver (tasveerein band): " + (saver ? "ON" : "OFF"),
                "Ads aur trackers block: " + (blockOn ? "ON" : "OFF") + " (" + blocked.get() + " band hue)",
                "Search engine: " + engineName(),
                "Page share karein",
                "Sab data mitao (cookies, cache, AI key)",
                "Safe DNS kaise on karein"
        };
        new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            newTab(HOME);
                            break;
                        case 1:
                            loadUrlIn(curWeb(), AI_HUB);
                            break;
                        case 2:
                            desktop = !desktop;
                            prefs.edit().putBoolean("desktop", desktop).apply();
                            for (Tab t : tabs) applyMode(t.web);
                            curWeb().reload();
                            break;
                        case 3:
                            saver = !saver;
                            prefs.edit().putBoolean("saver", saver).apply();
                            for (Tab t : tabs) applyMode(t.web);
                            curWeb().reload();
                            break;
                        case 4:
                            blockOn = !blockOn;
                            prefs.edit().putBoolean("block", blockOn).apply();
                            curWeb().reload();
                            break;
                        case 5:
                            engine = engine.equals("google") ? "startpage" : engine.equals("startpage") ? "ddg" : "google";
                            prefs.edit().putString("engine", engine).apply();
                            toast("Search engine: " + engineName());
                            break;
                        case 6:
                            shareCurrent();
                            break;
                        case 7:
                            wipe(true);
                            toast("Sab data mit gaya");
                            break;
                        case 8:
                            new AlertDialog.Builder(this)
                                    .setTitle("Safe DNS")
                                    .setMessage("Phone ki Settings kholein, phir Network & internet, phir Private DNS. 'Private DNS provider hostname' chunein aur dns.google ya one.one.one.one likhein.\n\nYe app DNS khud badal nahi sakti, ye phone ki setting se hota hai.")
                                    .setPositiveButton("Theek hai", null)
                                    .show();
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    void shareCurrent() {
        String u = curWeb().getUrl();
        if (u == null || u.contains(ASSET_HOST)) {
            toast("Share karne ke liye koi page kholein");
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, u);
        startActivity(Intent.createChooser(i, "Share karein"));
    }

    /* ---------------- Privacy cleanup ---------------- */

    void wipe(boolean everything) {
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        if (everything) WebStorage.getInstance().deleteAllData();
        for (Tab t : tabs) {
            t.web.clearCache(true);
            t.web.clearHistory();
            t.web.clearFormData();
        }
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) wipe(false);
        for (Tab t : tabs) t.web.destroy();
        super.onDestroy();
    }
}
