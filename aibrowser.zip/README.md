# AI Browser

Android app: private browser (Google search bina sign-in, ads/trackers block, history save nahi) aur "Sab AI Ek Sath" (coding, image, video, search, free AI, app development).

## APK kaise milti hai
1. Repo ke **Actions** tab mein "Build APK" chalta hai (har push par, ya "Run workflow" dabayein).
2. Build khatam hone par **Releases** mein `AIBrowser.apk` mil jati hai.
3. Phone par download karke install karein (Unknown sources allow karni parti hai).

## Zaroori baatein
- AI Hub mein OpenRouter key sirf phone mein save hoti hai (AI Hub ke Settings mein daalein).
- Safe DNS ke liye phone ki Private DNS setting use karein (dns.google ya one.one.one.one).
